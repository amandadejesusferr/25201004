-- up
ALTER TABLE VOO DROP CHECK chk_origem_destino_diferentes, DROP COLUMN origem;

-- down
ALTER TABLE VOO ADD COLUMN origem VARCHAR(80) NULL, ADD CONSTRAINT chk_origem_destino_diferentes CHECK (origem <> destino);