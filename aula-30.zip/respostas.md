# Atividade Prática: Migrations e Mudança Segura em Produção

---

## Parte 2: Pergunta 1
**Pergunta:** A coluna `portao_embarque` foi criada como `NULL`. O que aconteceria com o código do projeto, que ainda não conhece `portao_embarque`, se ela fosse `NOT NULL` sem valor padrão?

**Resposta:**  
Se a coluna fosse criada como `NOT NULL` sem um valor `DEFAULT`, qualquer operação de `INSERT` realizada pelo código antigo (que ainda não envia o valor de `portao_embarque`) iria falhar com um erro do MySQL (`SQLSTATE[HY000]: Field 'portao_embarque' doesn't have a default value`). Isso iria parar as operações de cadastro de novos voos na aplicação em produção.

---

## Parte 3: Pergunta 2
**Pergunta:** Execute `php migrate.php down` logo em seguida. A coluna `origem` volta, mas os dados voltam? Escreva, em uma frase, o que o `down` desta migration não consegue desfazer e o que você faria para recuperar os dados.

**Resposta:**  
O `down` recria a estrutura da coluna no esquema, mas não consegue desfazer a exclusão física e a perda definitiva dos dados que estavam nela antes do `DROP COLUMN`. Para recuperar os dados, seria necessário restaurar a coluna a partir de um backup feito antes da execução do `up`, ou executar um script de backfill inverso copiando os dados da coluna `aeroporto_origem` de volta para `origem` antes de aplicar a remoção.

---

## Parte 4: E se houvesse réplicas?

### 1. Lag de Replicação
* No primário: Um `UPDATE` sem `LIMIT` numa tabela de 5 milhões de registos gera uma transação massiva que bloqueia a tabela ou um volume gigante de linhas, impedindo escritas de outros utilizadores na aplicação.
* Nas réplicas: O evento de `UPDATE` entra no registo binário como um bloco gigante. Ao ser replicado, as réplicas demoram um tempo considerável a reprocessar essa transação sequencialmente, gerando um grande atraso na replicação e fazendo com que leituras nas réplicas devolvam dados desatualizados. O uso do `LIMIT` com pausas em lotes alivia a carga e permite a replicação fluida.

### 2. Ordem de Execução (Padrão Expandir e Contrair)
* O Passo 1 cria a nova coluna sem remover a antiga, garantindo compatibilidade com o código atual.
* O Passo 3 exige que a nova coluna já exista no banco. Ele deve ser concluído e implantado antes do Passo 4 para garantir que nenhuma consulta ou funcionalidade da aplicação continue dependente da coluna antiga.
* O Passo 4 só pode ocorrer quando todo o tráfego da aplicação estiver a utilizar a nova coluna.

### 3. Imutabilidade do Histórico de Migrations
Migrations já aplicadas em ambientes compartilhados ou em produção não devem ser editadas, porque alteram o histórico de versão (o conteúdo do ficheiro já não corresponderá ao que foi registado na `schema_migrations`), além de não serem reaplicadas em ambientes onde a versão `002` já consta como executada.  
Solução: Deve ser criada uma nova migration (ex.: `005_alter_tamanho_portao.sql`) que execute uma alteração para expandir o tamanho da coluna:
```sql
-- up
ALTER TABLE voos MODIFY COLUMN portao_embarque VARCHAR(10);

-- down
ALTER TABLE voos MODIFY COLUMN portao_embarque VARCHAR(5);
```

### 4. Backup e Irreversibilidade

O Passo 4 é o único irreversível sem backup. Trata-se de uma instrução DDL destrutiva (`DROP COLUMN`), que apaga fisicamente os dados armazenados no disco. Os Passos 1 e 2 apenas adicionam estrutura e duplicam dados, e o Passo 3 altera apenas o código da aplicação.